var express = require('express');
var router = express.Router();
var ssn;
/* GET home page. */
router.get('/', function(req, res, next) { 
  //Request session variable: 
  ssn = req.session;
  //Check if the user has signed up or logged in (else, redirect to the login page with error message there):
  if(ssn.email) {
    res.render('profile', {firstname: ssn.firstName, lastname: ssn.lastName});
  } else {
    ssn.profileError = "You need to log in first!";
    res.redirect('/login')
  }  
});

module.exports = router;