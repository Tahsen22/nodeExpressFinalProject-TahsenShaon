var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
  service: 'gmail', 
  auth: {
    user: 'mdr19812203@gmail.com',
    pass: 'Rashed223'
  }
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('contact');
});
router.post('/', function(req, res, next){
  res.render('contact', {message: 'Message sent!'});
  // receive the form data and store them in variables
  var fullName = req.body.name;
  var email = req.body.email;
  var message = req.body.message;
  // send an email to the webmaster
  var mailOptions = {
    from: 'mdr19812203@gmail.com',
    to: 'tahsen.rashed@gmail.com',
    subject: 'Contact Message from: ' + fullName,
    text: 'message: ' + message + '\n from: ' + email
  };
  transporter.sendMail(mailOptions, function(err, info){
    if (err) {
      console.log(err);
      res.render('contact', {error: 'Something went wrong!'});
    } else {
      console.log(info);
      res.render('contact', {message: 'Message Sent!'});
    }
  });
});
module.exports = router;
