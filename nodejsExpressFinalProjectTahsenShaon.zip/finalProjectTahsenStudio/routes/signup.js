var express = require('express');
const { sendStatus } = require('express/lib/response');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://Tahsen223:Rasha22@cluster0.ylvmn.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
var ssn;
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('signup');
});
router.post('/', function(req, res, next) {
  // capture data from the signup form and store them in variable
  ssn = req.session;
  ssn.firstName = req.body.fname;
  ssn.lastName = req.body.lname;
  ssn.email = req.body.email;
  var password = req.body.password;
  MongoClient.connect(url, function(err, db){
    if (err) throw err;
    var database = db.db("NodeJSClassProject");
    var userobj = {fname:ssn.firstName, lname:ssn.lastName, email:ssn.email, password:password};
    database.collection("uesrs").insertOne(userobj, function(err, res){
      if (err) throw err;
      console.log("user added to the users collection!");
      db.close();
    });
  });
  res.redirect('profile')
});
module.exports = router;