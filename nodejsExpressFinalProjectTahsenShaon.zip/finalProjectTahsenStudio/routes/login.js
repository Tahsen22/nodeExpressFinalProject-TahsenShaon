var express = require('express');
const { sendStatus } = require('express/lib/response');
var router = express.Router();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://Tahsen223:Rasha22@cluster0.ylvmn.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
var ssn;
router.get('/', function(req, res, next) {
  ssn = req.session;
  //Render the login page (only displays the error message if profile click invalid):
  res.render('login', {errorMessage: ssn.profileError});    
});

//Post to login page.
router.post('/', function(req, res, next){   

  //Request ssn:
  ssn = req.session;
  //Create session variables to have access to them on all pages:    
  ssn.email = req.body.email;
  var userPassword = req.body.password;        

  //Check to see if the user is stored in MongoDB.  Use the code from the findOne.js file where we did exactly that:
  MongoClient.connect(url, function(err, db){
      if(err){
          throw err;
      }    
      var database = db.db("NodeJSClassProject");
      var query = {email: ssn.email, password: userPassword};        
      
      database.collection("users").findOne(query, function(err, info){ 
      if(err) throw err;
      if(info){
          //user exists:
          console.log(info.fname);
          ssn.firstName = info.firstname;
          ssn.lastName = info.lastname;
          res.redirect('/profile');
      } else {
          //user does not exist:
          res.render('login', {errorMessage: 'Your login details are incorrect. Please login with the correct details.'});
      }
      });                          
  });     
});    

module.exports = router;